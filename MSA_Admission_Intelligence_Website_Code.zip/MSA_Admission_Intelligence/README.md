# MSA Admission Intelligence

A branded, responsive admissions analysis website. Vanilla HTML, CSS, JavaScript, and SVG; no framework build or CDN dependencies.

## Run locally

Install Python 3, open a terminal in this folder, and run:

```bash
python -m http.server 8000 --directory dist
```

Open http://localhost:8000. Use an HTTP server rather than double-clicking index.html because the app loads aggregate JSON with fetch.

## Files

- dist/index.html: report narrative, navigation, accessible controls and sections
- dist/styles.css: responsive navy/teal/gold identity and local font styling
- dist/app.js: cohort/month filters, SVG demand chart, topic/faculty bars, review details, impact scenarios, CSV/JSON downloads
- dist/calculations.mjs: bounded scenario calculation and spreadsheet-safe CSV exports
- dist/data.json: 20 precomputed aggregate views (broad/strict × full period/nine months)
- dist/MSA_2026_Senior_Admission_Report.pdf: full broad-cohort executive PDF; filters do not change it
- build_data.py: rebuild aggregate views using the previous Python analysis package
- check.mjs: data consistency, privacy, assets, scenario and export verification

## Update the analysis

First rebuild the existing Python analysis package from the original JSON, then:

```bash
python build_data.py --analysis-dir /path/to/msa_admissions_v2
node check.mjs
```

The builder imports analysis.py and reads data/analytics_2026.json from that package. It publishes aggregate summaries only. To update the PDF, copy the freshly rebuilt report into dist. The hero statistic and observation dates are written for the supplied 2026 dataset and must be reviewed when replacing the dataset or observation period.

## Definitions and limits

Coverage: Jan 1–Sep 15, 2026, Africa/Cairo. Visits are sessions with a 24-hour inactivity gap, not unique applicants. Broad includes strong and possible admission signals; strict includes strong only. Deterministic classifications are unvalidated. Topics and faculty mentions overlap. Repeated topics refer to a later visit from the same identifier and remain anchored to full-period history after filtering. Review exposure counts the union of mature query visits with a reply gap, topic repetition, or friction signal. It does not establish lost applicants or poor resolution.

Business replies may be automated. Timely-response denominators require 24-hour maturity. September is partial; fair comparison uses August/September days 1–15. Scenario reductions and handling minutes are editable assumptions, not measured savings or conversion forecasts. Enrollment, campaign attribution, and revenue are unavailable.

No participant names, identifiers, raw text or audit samples are included in the website. Private hosting is provided by the Site's access controls, not by a cosmetic password field. This is an independent analysis identity, not an official MSA website.

Local DejaVu fonts and their license are bundled. No user tracking, remote font requests or external chart libraries.

## Verification

Run node check.mjs and node --check dist/app.js. Aggregate full-period metrics are asserted against the previously verified Python decision summary during generation. Browser visual QA was unavailable in this execution environment; responsive breakpoints, accessible control labels, asset references, data consistency, and calculations were checked in source.
